﻿function isNull(str){
    if(str==""||str==null)
       return 1;
      }
	  function f(){
	  var sousuo = document.getElementById("sousuo").value;
	  if(isNull(sousuo)){alert("请输入关键字!");}
	  
	  }